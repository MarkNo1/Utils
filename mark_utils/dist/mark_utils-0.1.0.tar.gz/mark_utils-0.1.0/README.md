# Utils
For every python programmer arrive the moment to create his packages.
This is my utils repo.

## Includes:

## Preprocessing:
Some preprocessing util functions:

* Features matrix
    - Standardize (numpy, pytorch)
    - Normalize   (numpy, pytorch)

## PCA
Calculate the PCA (numpy, pytorch)

## Scraper
Wrapper for manager a FireFox browser with selenium library.


email:  marcotreglia1@gmail.com


# Usage
* Preprocessing

```python
from mark_utils.preprocessing import Standardize, Normalize

# Numpy
x = np.random.rand(100,5)
x = Standardize.numpy(x)
x = Normalize.numpy(x)

# Pytorch (cuda enable)
x = np.random.rand(100,5)
x = Standardize.torch(x)
x = Normalize.torch(x)


```


versione: 0.1.0
