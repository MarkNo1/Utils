# Utils
Some utils implemented both for pytorch and numpy


* Preprocessing: Standardize, Normalize
* PCA

email:  marcotreglia1@gmail.com


Some utils fuctions

versione: 0.0.4
