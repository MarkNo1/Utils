Creator:    MarkNo1 
email:  marcotreglia1@gmail.com


Some utils fuctions

versione: 0.0.2


